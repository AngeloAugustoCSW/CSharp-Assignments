using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Screens;

namespace ScrnLibs
{
    public class Buttons : Form
    {
        public Buttons()
        {}
        public void btnConfirmarClick(object sender, EventArgs e)
        {
            FormDentistMenuScrn MenuDentistaTelas = new FormDentistMenuScrn();
            MenuDentistaTelas.ShowDialog();
            
        }  
        public void btnVoltarClick(object sender, EventArgs e)
        {
            this.Close();
        }  
        
    }
}