using System;
using Controllers;
using Models;

namespace Views
{
    public class EspecialidadeViews
    {
        public static void InserirEspecialidade()
        {
            Console.WriteLine("Digite a decrição da especialidade");
            string Desc = Console.ReadLine();
            Console.WriteLine("Digite o detalhe da especialidade");
            string Detail = Console.ReadLine();


        
            EspecialidadeController.InsertEspecialidade(Desc,Detail);
        }
        public static void AlterarEspecialidade()
        {
            int Id=0;
            Console.WriteLine("Digite o ID da especialidade");
            try
            {
                Id=Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                throw new Exception("ID inválido");
            }
            Console.WriteLine("Digite a Descrição da Especialidade: ");
            string Desc = Console.ReadLine();
            Console.WriteLine("Digite o detalhe da Especialidade: ");
            string Detail = Console.ReadLine();

            EspecialidadeController.UpdateEspecialidade(Id,Desc,Detail);
        }
        public static void ExcluirEspecialidade()
        {
            int Id = 0;
            Console.WriteLine("Digite o ID da Especialidade: ");
            try
            {
                Id = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                throw new Exception("ID inválido.");
            }
            
            EspecialidadeController.DeleteEspecialidade(Id);
        }
         public static void ListarEspecialidades()
        {
            foreach (Especialidade item in EspecialidadeController.SelectEspecialidade())
            {
                Console.WriteLine(item);
            }
        }
    }
}