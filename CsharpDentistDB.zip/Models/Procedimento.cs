using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System;
using DB;


namespace Models
{
    public class Procedimento
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
        public double Preco { get; set; }

        public Procedimento()
        {
        }

        public Procedimento(
            string Descricao,
            double Preco
        )
        {
            this.Id = Id;
            this.Descricao = Descricao;
            this.Preco = Preco;
            Context db = new Context();
            db.Procedimentos.Add(this);
            db.SaveChanges();
        }
        public static List<Procedimento> GetProcedimentos()
        {
            Context db = new Context();
            return (from Procedimento in db.Procedimentos select Procedimento).ToList();
        }
        public static void RemoverProcedimento(Procedimento procedimento)
        {
            Context db = new Context();
            db.Procedimentos.Remove(procedimento);
        }
        public override bool Equals(object o)
        {
            if(o == null)
            {
                return false;
            }
            if (!Procedimento.ReferenceEquals(o, this))
            {
                return false;
            }
            Procedimento p = (Procedimento) o;
            return p.Id == this.Id;
        }
        public override string ToString()
        {
            return$"\n ---------------------------------------"
                  +$"ID: {this.Id}"
                  +$"\n Descrição: {this.Descricao}"
                  +$"\n Preço: {this.Preco}";
        }
    }
}