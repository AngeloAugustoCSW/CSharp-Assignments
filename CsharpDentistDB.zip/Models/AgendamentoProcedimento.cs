using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System;
using DB;

namespace Models
{
    public class AgendamentoProcedimento
    {
        public int Id {get; set;}
        public int AgendamentoId {get; set;}
        public int ProcedimentoId {get; set;}
        public Agendamento Agendamento { get; set; }
        public AgendamentoProcedimento()
        {
        }

        public AgendamentoProcedimento(int AgendamentoId,
                                        int ProcedimentoId)
        {
            this.Id = Id;
            this.AgendamentoId = AgendamentoId;
            this.ProcedimentoId = ProcedimentoId;

            Context db = new Context();
            db.AgendamentosProcedimentos.Add(this);
            db.SaveChanges();
        }

        public static List<AgendamentoProcedimento> GetAgendamentoProcedimentos()
        {
            Context db = new Context();
            return (from AgendamentoProcedimento in db.AgendamentosProcedimentos select AgendamentoProcedimento).ToList();
        }

        public static void RemoverAgendamentoProcedimento(AgendamentoProcedimento agendamentoProcedimento)
        {
            Context db = new Context();
            db.AgendamentosProcedimentos.Remove(agendamentoProcedimento);
        }

        public override bool Equals(object obj)
        {
            if(obj == null)
            {
                return false;
            }

            if(!AgendamentoProcedimento.ReferenceEquals(obj, this))
            {
                return false;
            }

            AgendamentoProcedimento ap = (AgendamentoProcedimento) obj;
            return ap.Id == this.Id;

        }


        public override string ToString()
        {
            return $"\n ---------------------------------------" +
                   $"\n Id: {this.Id}" + 
                   $"\n Id Agendamento: {this.AgendamentoId}" +
                   $"\n Id Procedimento: {this.ProcedimentoId}";
        }
    }
}