using System;
using System.Collections.Generic;

namespace Models
{
    public class Procedimento
    {
        public static int ID = 0;
        public int Id { get; set; }
        public string Descricao { get; set; }
        public double Preco { get; set; }
        private static List<Procedimento> Procedimentos = new List<Procedimento>();

        public Procedimento(
            string Descricao,
            double Preco) 
            : this(++ID, Descricao, Preco)
        {
        }

        private Procedimento(
            int id,
            string Descricao,
            double Preco
        )
        {
            this.Id = Id;
            this.Descricao = Descricao;
            this.Preco = Preco;

            Procedimentos.Add(this);
        }
        public static List<Procedimento> GetProcedimentos()
        {
            return Procedimentos;
        }
        public static void RemoverProcedimento(Procedimento procedimento)
        {
            Procedimentos.Remove(procedimento);
        }
        public override bool Equals(object o)
        {
            if(o == null)
            {
                return false;
            }
            if (!Procedimento.ReferenceEquals(o, this))
            {
                return false;
            }
            Procedimento p = (Procedimento) o;
            return p.Id == this.Id;
        }
        public override string ToString()
        {
            return$"\n ---------------------------------------"
                  +$"ID: {this.Id}"
                  +$"\n Descrição: {this.Descricao}"
                  +$"\n Preço: {this.Preco}";
        }
    }
}